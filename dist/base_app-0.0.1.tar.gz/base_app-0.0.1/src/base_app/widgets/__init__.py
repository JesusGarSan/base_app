from widgets import maps
from widgets import forms
from widgets import tables
from widgets import plots