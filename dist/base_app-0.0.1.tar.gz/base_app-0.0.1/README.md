# base_app
Base configuration for my streamlit applications
