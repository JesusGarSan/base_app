import src.base_app as base_app

header_elements = [
{
    "page_name": "Home",
    "filepath": "/pages/home.py" ,
    "icon": "🏠"
},

]